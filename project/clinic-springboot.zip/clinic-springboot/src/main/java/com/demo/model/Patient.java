package com.demo.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "patient")

public class Patient {

	@Id
    @GeneratedValue(strategy = GenerationType.AUTO)
	private int id;
	private String name;
	private int age;
	private String gender;
	private String address;
	
	private String consulted_doctor;
	private String vaccination_status;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getConsulted_doctor() {
		return consulted_doctor;
	}
	public void setConsulted_doctor(String consulted_doctor) {
		this.consulted_doctor = consulted_doctor;
	}
	public String getVaccination_status() {
		return vaccination_status;
	}
	public void setVaccination_status(String vaccination_status) {
		this.vaccination_status = vaccination_status;
	}
	
    
}
